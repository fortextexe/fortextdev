export default function Header() {
  return (
    <>
      <div className='h-2 bg-cyan-600'>

      </div>
    </>
  );
}
