
![romanwashere.xyz](https://cdn.discordapp.com/attachments/1140699500311236719/1179468189114048533/1_-bG_xAqurVd0T35ulOYu0Q_1.png)
## romanwashere.xyz ☁ v2.0
Bu proje web sitemin kaynak kodlarının bulunduğu bir depodur. Açık kaynaklı olup istediğiniz şekilde kullanabilirsiniz.


  
## Yükleme 
Projenin gereksinimi olan paketleri mevcut paket yöneticiniz ile projeye indirebilirsiniz, ben genel olarak `pnpm` kullanıyorum.

```bash 
  npm install
  pnpm install
  yarn
```
    
## Demo
Demo görüntüsü için [romanwashere.xyz](https://romanwashere.xyz/) adresine girerek görüntüleyebilirsiniz.

  
## Yazarlar ve Teşekkür

- [@ewgsta](https://www.github.com/ewgsta) tarafından kodlanmış ve tasarlanmıştır, izni dışında hiç bir yerde paylaşılamaz.

  
